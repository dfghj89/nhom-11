# Lab 4 — Time Series (Beijing PM2.5): Regression baseline vs ARIMA

Repo template để bạn chạy đúng pipeline theo yêu cầu Lab-4:
1) `preprocessing_and_eda.ipynb`
2) `regression_modelling.ipynb`
3) `arima_forecasting.ipynb`

## 1) Chuẩn bị dữ liệu
- Tải file zip **PRSA2017_Data_20130301-20170228.zip**
- Đặt đúng đường dẫn: `data/raw/PRSA2017_Data_20130301-20170228.zip`

## 2) Cài môi trường
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate
pip install -r requirements.txt
```

## 3) Chạy pipeline tự động (khuyến nghị)
```bash
python run_papermill.py
```

Notebook output sẽ được lưu vào `notebooks/runs/` (để nộp/báo cáo).

## 4) Tham số quan trọng
Bạn có thể chỉnh trong `run_papermill.py`:
- `RAW_ZIP_PATH`
- `CUTOFF`
- `LAG_HOURS`
- `HORIZON`
- `STATION`

## 5) Artifacts xuất ra
- `data/processed/cleaned.parquet`
- `data/processed/regression_metrics.json`
- `data/processed/arima_metrics.json`
- (tuỳ chọn) `data/processed/regression_predictions.parquet`, `data/processed/arima_predictions.parquet`

## 6) Gợi ý nộp bài
- Link GitHub repo
- Blog/report (markdown hoặc Notion link)
- 04 hình bắt buộc: PM2.5 full, PM2.5 zoom 1–2 tháng, ACF/PACF, Forecast vs Actual (ARIMA)
- Tối thiểu 05 insight + khuyến nghị hành động

Chúc bạn chạy mượt 🚀
