from __future__ import annotations

import datetime as dt
from pathlib import Path
import papermill as pm


# ====== CONFIG (edit here) ======
RAW_ZIP_PATH = "data/raw/PRSA2017_Data_20130301-20170228.zip"
CLEANED_PATH = "data/processed/cleaned.parquet"

STATION = "Aotizhongxin"
CUTOFF = "2017-01-01"
LAG_HOURS = [1, 3, 24]
HORIZON = 1

REG_METRICS_PATH = "data/processed/regression_metrics.json"
ARIMA_METRICS_PATH = "data/processed/arima_metrics.json"
# =================================


def run_one(in_path: Path, out_path: Path, params: dict) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    pm.execute_notebook(
        input_path=str(in_path),
        output_path=str(out_path),
        parameters=params,
        log_output=True,
    )


def main() -> None:
    ts = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    runs_dir = Path("notebooks/runs") / ts
    runs_dir.mkdir(parents=True, exist_ok=True)

    run_one(
        Path("notebooks/preprocessing_and_eda.ipynb"),
        runs_dir / "preprocessing_and_eda.run.ipynb",
        {
            "raw_zip_path": RAW_ZIP_PATH,
            "output_cleaned_path": CLEANED_PATH,
            "lag_hours": LAG_HOURS,
        },
    )

    run_one(
        Path("notebooks/regression_modelling.ipynb"),
        runs_dir / "regression_modelling.run.ipynb",
        {
            "cleaned_path": CLEANED_PATH,
            "station": STATION,
            "cutoff": CUTOFF,
            "horizon": HORIZON,
            "lag_hours": LAG_HOURS,
            "output_metrics_path": REG_METRICS_PATH,
            "output_predictions_path": "data/processed/regression_predictions.parquet",
        },
    )

    run_one(
        Path("notebooks/arima_forecasting.ipynb"),
        runs_dir / "arima_forecasting.run.ipynb",
        {
            "cleaned_path": CLEANED_PATH,
            "station": STATION,
            "cutoff": CUTOFF,
            "horizon": HORIZON,
            "p_max": 3,
            "q_max": 3,
            "output_metrics_path": ARIMA_METRICS_PATH,
            "output_predictions_path": "data/processed/arima_predictions.parquet",
        },
    )

    print(f"Done. Outputs saved to: {runs_dir}")


if __name__ == "__main__":
    main()
